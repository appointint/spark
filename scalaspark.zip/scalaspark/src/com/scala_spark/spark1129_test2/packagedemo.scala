package com.it18zhang{
    package my{
      class Cat{
         val color = "yellow"
      }
    }
    package myscala{
      class Dog{
        
      }
    }
}
