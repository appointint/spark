package question;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class WordCount {

	public static void main(String[] args) {
		// TODO �Զ����ɵķ������
		
		String str="java java scala hello scala hello python";
		String[] strings=str.split(" ");
		HashMap<String, String>map=new HashMap<String,String>();
		
		
/*		for (int i = 0; i < map.size(); i++) {
		
				
				if (map.containsKey(i)==map.containsKey(j)) {
					map.put(strings[j], map.get(strings[j]+1));
				}
			
		}
		

		Set<Map.Entry<String, String>> set=map.entrySet();
		
		for(Map.Entry set:set){
			
		}
		*/
		
//		for(String string: set){
//			System.out.println(+"    "+);
//		}
		
		

	}

}
